"""License wire format shared by the service and compiled desktop client."""
