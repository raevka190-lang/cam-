import base64,hashlib,json,re
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
AUD='cam-nesting-desktop-v1'
DAY=86400
TRIAL_DAYS=14
REFRESH_SECONDS=DAY
LEASE_SECONDS=3*DAY
MAX_BODY=16384
class ProtocolError(ValueError):pass

def canonical(value):return json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode('ascii')
def b64(data):return base64.urlsafe_b64encode(data).decode('ascii').rstrip('=')
def unb64(value,length=None):
    if not isinstance(value,str) or len(value)>MAX_BODY or not re.fullmatch(r'[A-Za-z0-9_-]+',value):raise ProtocolError('Invalid base64')
    try:raw=base64.b64decode(value+'='*((-len(value))%4),altchars=b'-_',validate=True)
    except ValueError:raise ProtocolError('Invalid base64') from None
    if length is not None and len(raw)!=length:raise ProtocolError('Invalid key/signature length')
    return raw

def public_bytes(key):return key.public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw)
def key_id(key):return hashlib.sha256(public_bytes(key)).hexdigest()[:20]
def sign(payload,key):return dict(kid=key_id(key.public_key()),payload=payload,signature=b64(key.sign(canonical(payload))))
def verify(envelope,keys):
    if not isinstance(envelope,dict) or set(envelope)!={'kid','payload','signature'}:raise ProtocolError('Invalid signed message')
    if not isinstance(envelope['kid'],str) or len(envelope['kid'])>100:raise ProtocolError('Invalid signing key identifier')
    raw=keys.get(envelope['kid'])
    if raw is None:raise ProtocolError('Unknown signing key')
    payload=envelope['payload']
    if not isinstance(payload,dict) or payload.get('aud')!=AUD or payload.get('v')!=1:raise ProtocolError('Wrong license product/format')
    try:Ed25519PublicKey.from_public_bytes(unb64(raw,32)).verify(unb64(envelope['signature'],64),canonical(payload))
    except Exception as exc:raise ProtocolError('Signature check failed') from exc
    return payload

def check_identity(device,public):
    if not isinstance(device,str) or not re.fullmatch(r'[0-9a-f]{64}',device):raise ProtocolError('Invalid device hash')
    unb64(public,32)
def integer(payload,name):
    value=payload.get(name)
    if type(value) is not int or value<0:raise ProtocolError('Invalid '+name)
    return value
