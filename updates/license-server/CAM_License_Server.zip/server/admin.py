"""Local server administration; never ship this module or a signing key to customers."""
import argparse,json,os,sqlite3,shutil,contextlib,hashlib
from pathlib import Path
from datetime import datetime,timezone
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cam_license.protocol import b64,key_id,public_bytes,sign,AUD
from .store import Service

def init(folder):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    if os.name!='nt':os.chmod(folder,0o700)
    key=Ed25519PrivateKey.generate();path=folder/'signing-key.pem'
    pem=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(pem)
    service=Service(folder/'licenses.sqlite3',path,initialize=True)
    public={key_id(key.public_key()):b64(public_bytes(key.public_key()))}
    (folder/'public-keys.json').write_text(json.dumps(public,indent=2)+'\n',encoding='utf-8')
    return service

def main():
    p=argparse.ArgumentParser(description='CAM license administration (run only on your server)');p.add_argument('--state-dir',default=os.environ.get('CAM_LICENSE_STATE','/var/lib/cam-license'));sub=p.add_subparsers(dest='action',required=True);sub.add_parser('init');sub.add_parser('list')
    for action in ('paid','revoke','restore','reset-device'):
        command=sub.add_parser(action);command.add_argument('license_id')
        if action=='paid':command.add_argument('--days',type=int,required=True)
    backup=sub.add_parser('backup');backup.add_argument('destination',type=Path)
    release=sub.add_parser('sign-release');release.add_argument('file',type=Path);release.add_argument('--version',required=True);release.add_argument('--out',type=Path,required=True)
    args=p.parse_args();root=Path(args.state_dir)
    if args.action=='init':init(root);print('Created server state. Copy ONLY public-keys.json to the release builder. Back up the private state securely.');return
    service=Service(root/'licenses.sqlite3',root/'signing-key.pem')
    if args.action=='sign-release':
        if not args.file.is_file() or args.file.suffix.lower() not in ('.exe','.zip'):raise ValueError('Select the compiled customer EXE or ZIP')
        if not args.version or len(args.version)>100:raise ValueError('Specify release version')
        with args.file.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
        payload=dict(v=1,aud=AUD,kind='release',platform='windows-x64',version=args.version,filename=args.file.name,sha256=digest,size=args.file.stat().st_size)
        with args.out.open('x',encoding='utf-8') as f:json.dump(sign(payload,service.key),f,ensure_ascii=False,indent=2)
        print('Release manifest signed. Distribute this manifest with the matching compiled installer; never distribute server state.');return
    if args.action=='backup':
        dest=args.destination;dest.mkdir(mode=0o700,parents=False,exist_ok=False)
        with contextlib.closing(service.connect()) as src,contextlib.closing(sqlite3.connect(dest/'licenses.sqlite3')) as target:src.backup(target)
        for name in ('signing-key.pem','public-keys.json'):shutil.copyfile(root/name,dest/name)
        if os.name!='nt':
            for file in dest.iterdir():os.chmod(file,0o600)
        print('Private backup created. Keep it encrypted and separate from customer downloads.');return
    if args.action=='list':
        for row in service.list():
            row['started']=datetime.fromtimestamp(row['started'],timezone.utc).isoformat();row['expires']=datetime.fromtimestamp(row['expires'],timezone.utc).isoformat();print(json.dumps(row,ensure_ascii=False))
    else:service.update(args.license_id,args.action,getattr(args,'days',None));print('Updated',args.license_id)
if __name__=='__main__':main()
