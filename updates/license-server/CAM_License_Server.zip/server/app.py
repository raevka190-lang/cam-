import os
from pathlib import Path
from fastapi import FastAPI,HTTPException,Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel,ConfigDict,Field
from cam_license.protocol import MAX_BODY,ProtocolError
from .store import Service,RateLimited,ClockError
class Challenge(BaseModel):
    model_config=ConfigDict(extra='forbid',strict=True)
    device:str=Field(min_length=64,max_length=64)
    public:str=Field(min_length=43,max_length=43)
    client_nonce:str=Field(min_length=43,max_length=43)
class Lease(BaseModel):
    model_config=ConfigDict(extra='forbid',strict=True)
    challenge:dict
    proof:str=Field(min_length=86,max_length=86)
def create_app(service):
    app=FastAPI(title='CAM license service',docs_url=None,redoc_url=None,openapi_url=None)
    @app.middleware('http')
    async def limit(request,call_next):
        if request.method=='POST':
            try:length=int(request.headers['content-length'])
            except (KeyError,ValueError):return JSONResponse({'detail':'Content-Length required'},status_code=411)
            if not 0<length<=MAX_BODY:return JSONResponse({'detail':'Request too large'},status_code=413)
        response=await call_next(request);response.headers['Cache-Control']='no-store';return response
    def invoke(fn,*args):
        try:return fn(*args)
        except ProtocolError:raise HTTPException(400,'Invalid license request') from None
        except RateLimited:raise HTTPException(429,'Too many requests',headers={'Retry-After':'3600'}) from None
        except ClockError:raise HTTPException(503,'License service time unavailable') from None
    @app.get('/health')
    def health():return {'ok':True,'protocol':1}
    @app.post('/v1/challenge')
    def challenge(data:Challenge,request:Request):return invoke(service.challenge,data.device,data.public,data.client_nonce,request.client.host if request.client else 'unknown')
    @app.post('/v1/lease')
    def lease(data:Lease,request:Request):return invoke(service.lease,data.challenge,data.proof,request.client.host if request.client else 'unknown')
    return app

def from_env():
    state=Path(os.environ.get('CAM_LICENSE_STATE','/var/lib/cam-license'))
    return create_app(Service(state/'licenses.sqlite3',state/'signing-key.pem'))
