import contextlib,hashlib,sqlite3,time,uuid,secrets,os
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cam_license.protocol import *
class RateLimited(Exception):pass
class ClockError(Exception):pass
class Service:
    def __init__(self,database,key_file,clock=time.time,initialize=False):
        self.database=Path(database);self.clock=clock
        self.key=serialization.load_pem_private_key(Path(key_file).read_bytes(),password=None)
        if not isinstance(self.key,Ed25519PrivateKey):raise ValueError('Expected Ed25519 signing key')
        self.public_keys={key_id(self.key.public_key()):b64(public_bytes(self.key.public_key()))}
        self.database.parent.mkdir(parents=True,exist_ok=True)
        if not initialize and not self.database.is_file():raise ValueError('License database is missing; restore the server backup. Do not initialize a replacement database.')
        with contextlib.closing(self.connect()) as con:
            if initialize:
                con.executescript('''PRAGMA journal_mode=WAL;
CREATE TABLE meta (name TEXT PRIMARY KEY,value INTEGER NOT NULL);
CREATE TABLE licenses (id TEXT PRIMARY KEY,device TEXT UNIQUE NOT NULL,public TEXT,started INTEGER NOT NULL,expires INTEGER NOT NULL,tier TEXT NOT NULL,revoked INTEGER NOT NULL DEFAULT 0);
CREATE TABLE used_challenges (nonce TEXT PRIMARY KEY,expires INTEGER NOT NULL);
CREATE TABLE rates (bucket TEXT PRIMARY KEY,start INTEGER NOT NULL,count INTEGER NOT NULL);
INSERT INTO meta VALUES('schema',1);
''')
            row=con.execute("SELECT value FROM meta WHERE name='schema'").fetchone()
            if row is None or row['value']!=1:raise ValueError('Unsupported or damaged license database')
        if os.name!='nt':os.chmod(self.database,0o600)
    def connect(self):
        con=sqlite3.connect(self.database,timeout=10,isolation_level=None);con.row_factory=sqlite3.Row;con.execute('PRAGMA busy_timeout=10000');return con
    @contextlib.contextmanager
    def transaction(self):
        con=self.connect()
        try:
            con.execute('BEGIN IMMEDIATE');yield con;con.commit()
        except BaseException:con.rollback();raise
        finally:con.close()
    def now(self,con):
        now=int(self.clock());last=con.execute("SELECT value FROM meta WHERE name='last_time'").fetchone()
        if last and now<last['value']-300:raise ClockError('Server clock rollback; correct UTC time before issuing licenses')
        now=max(now,last['value'] if last else now);con.execute("INSERT INTO meta VALUES('last_time',?) ON CONFLICT(name) DO UPDATE SET value=excluded.value",(now,));return now
    def rate(self,con,bucket,now,limit,period=3600):
        row=con.execute('SELECT start,count FROM rates WHERE bucket=?',(bucket,)).fetchone()
        if row and now-row['start']<period:
            if row['count']>=limit:raise RateLimited()
            con.execute('UPDATE rates SET count=count+1 WHERE bucket=?',(bucket,))
        else:con.execute('INSERT INTO rates VALUES(?,?,1) ON CONFLICT(bucket) DO UPDATE SET start=excluded.start,count=1',(bucket,now))
    def challenge(self,device,public,client_nonce,ip):
        check_identity(device,public);unb64(client_nonce,32)
        with self.transaction() as con:
            now=self.now(con);self.rate(con,'ip:'+ip,now,500);self.rate(con,'device:'+device,now,120)
            con.execute('DELETE FROM used_challenges WHERE expires<?',(now,));con.execute('DELETE FROM rates WHERE start<?',(now-2*DAY,))
        return sign(dict(v=1,aud=AUD,kind='challenge',device=device,public=public,client_nonce=client_nonce,nonce=b64(secrets.token_bytes(32)),issued_at=now,expires=now+300),self.key)
    def lease(self,envelope,proof,ip):
        p=verify(envelope,self.public_keys)
        if p.get('kind')!='challenge':raise ProtocolError('Expected challenge')
        check_identity(p.get('device'),p.get('public'));unb64(p.get('nonce'),32)
        try:Ed25519PublicKey.from_public_bytes(unb64(p['public'],32)).verify(unb64(proof,64),canonical(p))
        except Exception as exc:raise ProtocolError('Device proof failed') from exc
        with self.transaction() as con:
            now=self.now(con);self.rate(con,'lease-ip:'+ip,now,500)
            if not integer(p,'issued_at')<=now<integer(p,'expires'):raise ProtocolError('Challenge expired')
            try:con.execute('INSERT INTO used_challenges VALUES(?,?)',(p['nonce'],p['expires']))
            except sqlite3.IntegrityError:raise ProtocolError('Challenge already used') from None
            row=con.execute('SELECT * FROM licenses WHERE device=?',(p['device'],)).fetchone()
            if row is None:
                ident=str(uuid.uuid4());con.execute('INSERT INTO licenses VALUES(?,?,?,?,?,?,0)',(ident,p['device'],p['public'],now,now+TRIAL_DAYS*DAY,'trial'));row=con.execute('SELECT * FROM licenses WHERE id=?',(ident,)).fetchone()
            elif row['public'] is None:
                con.execute('UPDATE licenses SET public=? WHERE id=?',(p['public'],row['id']));row=con.execute('SELECT * FROM licenses WHERE id=?',(row['id'],)).fetchone()
            status='active'
            if row['public']!=p['public']:status='device_conflict'
            elif row['revoked']:status='revoked'
            elif now>=row['expires']:status='expired'
            payload=dict(v=1,aud=AUD,kind='lease',status=status,license_id=row['id'],device=p['device'],public=p['public'],client_nonce=p['client_nonce'],tier=row['tier'],started_at=row['started'],license_expires=row['expires'],issued_at=now,refresh_after=min(now+REFRESH_SECONDS,row['expires']),lease_until=min(now+LEASE_SECONDS,row['expires']),capabilities=['nesting','nc_export'] if status=='active' else [])
        return sign(payload,self.key)
    def list(self):
        with contextlib.closing(self.connect()) as con:return [dict(r) for r in con.execute('SELECT id,device,started,expires,tier,revoked FROM licenses ORDER BY started DESC')]
    def update(self,ident,action,days=None):
        with self.transaction() as con:
            now=self.now(con);row=con.execute('SELECT * FROM licenses WHERE id=?',(ident,)).fetchone()
            if row is None:raise ValueError('License not found')
            if action=='paid':
                if type(days) is not int or not 1<=days<=3650:raise ValueError('Days: 1..3650')
                con.execute("UPDATE licenses SET tier='paid',expires=?,revoked=0 WHERE id=?",(max(now,row['expires'] if row['tier']=='paid' else now)+days*DAY,ident))
            elif action=='revoke':con.execute('UPDATE licenses SET revoked=1 WHERE id=?',(ident,))
            elif action=='restore':con.execute('UPDATE licenses SET revoked=0 WHERE id=?',(ident,))
            elif action=='reset-device':con.execute('UPDATE licenses SET public=NULL WHERE id=?',(ident,))
            else:raise ValueError('Unknown action')
