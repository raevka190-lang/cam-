#!/usr/bin/env bash
set -euo pipefail
trap 'echo "Setup stopped at line $LINENO. Send the error text; do not delete license state." >&2' ERR
APP=/opt/cam-license
STATE=/var/lib/cam-license
HOST=license.cam-nesting.ru
ADDRESS=45.12.75.131
if [ "$(id -u)" != 0 ]; then echo 'Run as root.'; exit 1; fi
cd "$APP"
for file in server/app.py server/admin.py cam_license/protocol.py requirements-server.txt deployment/cam-license.service; do
    if [ ! -f "$file" ]; then echo "Missing $file. Extract the complete server archive into /opt/cam-license."; exit 1; fi
done
for command in python3 runuser systemctl caddy; do command -v "$command" >/dev/null || { echo "Missing $command. Install python3-venv, unzip and caddy first."; exit 1; }; done
if ! id camlicense >/dev/null 2>&1; then useradd --system --home "$STATE" --shell /usr/sbin/nologin camlicense; fi
if [ -L "$STATE" ] || [ -L "$APP" ]; then echo 'Installation directories must not be symbolic links.'; exit 1; fi
install -d -o camlicense -g camlicense -m 700 "$STATE"
chown -hR root:camlicense "$APP"
chmod -R u=rwX,g=rX,o= "$APP"
echo 'Creating Python environment and installing server dependencies...'
python3 -m venv "$APP/.venv"
"$APP/.venv/bin/python" -m pip install --disable-pip-version-check -r requirements-server.txt
if [ ! -e "$STATE/signing-key.pem" ] && [ ! -e "$STATE/licenses.sqlite3" ]; then
    echo 'Initializing a new private signing key and activation database on this server.'
    runuser -u camlicense -- "$APP/.venv/bin/python" -m server.admin init
elif [ -f "$STATE/signing-key.pem" ] && [ -f "$STATE/licenses.sqlite3" ]; then
    echo 'Existing signing key and database retained.'
else
    echo 'Incomplete license state. Restore its backup; do not generate a replacement key/database.'
    exit 1
fi
# Verify that the service user can read the existing state. No private material is printed.
runuser -u camlicense -- "$APP/.venv/bin/python" -m server.admin list >/dev/null
install -m 644 deployment/cam-license.service /etc/systemd/system/cam-license.service
systemctl daemon-reload
systemctl enable --now cam-license
systemctl restart cam-license
"$APP/.venv/bin/python" - <<'PY'
import json,time,urllib.request
for attempt in range(20):
    try:
        with urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=2) as response:body=json.load(response)
        if body=={'ok':True,'protocol':1}:break
    except (OSError,ValueError):pass
    time.sleep(.5)
else:raise SystemExit('Local service health check failed. Run: journalctl -u cam-license -n 30 --no-pager')
print('Local activation service is healthy.')
PY
# Configure only the managed hostname, preserving unrelated Caddy sites.
if ! "$APP/.venv/bin/python" - <<'PY'
import socket
try:addresses={r[4][0] for r in socket.getaddrinfo('license.cam-nesting.ru',None,socket.AF_INET)}
except OSError:addresses=set()
if '45.12.75.131' not in addresses:raise SystemExit('DNS is not ready: license.cam-nesting.ru must resolve to 45.12.75.131. Save the DNS record, wait, and run setup again. Existing license state is retained.')
PY
then exit 1; fi
MAIN=/etc/caddy/Caddyfile
SITE=/etc/caddy/conf.d/cam-license.caddy
MARKER='# Managed by CAM license server setup'
if [ ! -f "$MAIN" ] || [ -L "$MAIN" ] || [ -L "$SITE" ]; then echo 'Unexpected Caddy configuration path. Review it manually.'; exit 1; fi
if [ -f "$SITE" ] && ! grep -Fqx "$MARKER" "$SITE"; then echo 'An unmanaged configuration already exists for this site. Review it manually.'; exit 1; fi
if grep -Fq "$HOST" "$MAIN"; then echo 'Hostname already appears in the main Caddyfile. Review existing configuration; it was not overwritten.'; exit 1; fi
install -d -m 755 /etc/caddy/conf.d
STAMP=$(date -u +%Y%m%dT%H%M%S)-$$
BACKUP="$MAIN.cam-backup-$STAMP"
cp -p "$MAIN" "$BACKUP"
OLD_SITE=''
if [ -f "$SITE" ]; then OLD_SITE="$SITE.cam-backup-$STAMP"; cp -p "$SITE" "$OLD_SITE"; fi
cat > "$SITE" <<'EOF'
# Managed by CAM license server setup
license.cam-nesting.ru {
    reverse_proxy 127.0.0.1:8000
}
EOF
chmod 644 "$SITE"
if ! grep -Fqx 'import /etc/caddy/conf.d/*.caddy' "$MAIN"; then
    printf '\nimport /etc/caddy/conf.d/*.caddy\n' >> "$MAIN"
fi
if ! caddy validate --config "$MAIN"; then
    cp -p "$BACKUP" "$MAIN"
    if [ -n "$OLD_SITE" ]; then cp -p "$OLD_SITE" "$SITE"; else rm -f "$SITE"; fi
    echo 'Caddy validation failed; its previous configuration was restored.'
    exit 1
fi
systemctl enable --now caddy
if ! systemctl reload caddy; then
    cp -p "$BACKUP" "$MAIN"
    if [ -n "$OLD_SITE" ]; then cp -p "$OLD_SITE" "$SITE"; else rm -f "$SITE"; fi
    echo 'Caddy reload failed; previous configuration restored. Check journalctl -u caddy.'
    exit 1
fi
echo
echo 'Installation completed. Caddy may need a short time to obtain the HTTPS certificate.'
echo 'Open in your browser: https://license.cam-nesting.ru/health'
echo 'Expected reply: {"ok":true,"protocol":1}'
echo 'Public client configuration: /var/lib/cam-license/public-keys.json'
echo 'Never send signing-key.pem or licenses.sqlite3 to anyone or put them on a public website.'
echo 'Keep a private backup of the signing key and database before issuing customer licenses.'
